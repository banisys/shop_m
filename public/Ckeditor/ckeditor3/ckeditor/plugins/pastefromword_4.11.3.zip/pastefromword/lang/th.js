/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'th', {
	confirmCleanup: 'ข้อความที่คุณต้องการวางลงไปเป็นข้อความที่คัดลอกมาจากโปรแกรมไมโครซอฟท์เวิร์ด คุณต้องการล้างค่าข้อความดังกล่าวก่อนวางลงไปหรือไม่?',
	error: 'ไม่สามารถล้างข้อมูลที่ต้องการวางได้เนื่องจากเกิดข้อผิดพลาดภายในระบบ',
	title: 'วางสำเนาจากตัวอักษรเวิร์ด',
	toolbar: 'วางสำเนาจากตัวอักษรเวิร์ด'
} );
